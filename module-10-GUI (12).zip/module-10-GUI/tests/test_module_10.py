"""Pytest for the CIS245 Module 10 weather GUI.

Copy this file to the student's tests directory. It checks pure functions
and source text. It must not construct a tkinter.Tk window.

Remove this file at the start of Module 11. It asserts that urllib is not
used, and the Module 11 program does use urllib.
"""

from __future__ import annotations

import ast
import importlib.util
import sys
import urllib.request
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
if (HERE / "weather_app.py").is_file():
    APP_DIR = HERE
elif (HERE.parent / "weather_app.py").is_file():
    APP_DIR = HERE.parent
else:
    APP_DIR = HERE.parent


def _load_weather_app():
    """Load weather_app.py from this project, even if another copy was imported."""
    path = APP_DIR / "weather_app.py"
    name = "weather_app_" + Path(__file__).stem
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


weather_app = _load_weather_app()


ALL_FIELDS = {"conditions", "temperature", "feels_like", "humidity", "wind"}

IMPERIAL_ALL = [
    "City: Bellevue",
    "Conditions: clear sky",
    "Temperature: 72.0 F",
    "Feels like: 70.0 F",
    "Humidity: 40%",
    "Wind: 8.0 mph",
]

METRIC_ALL = [
    "City: Bellevue",
    "Conditions: clear sky",
    "Temperature: 22.0 C",
    "Feels like: 21.0 C",
    "Humidity: 40%",
    "Wind: 3.6 m/s",
]

REQUIRED_ATTRIBUTES = {
    "main_window",
    "zip_entry",
    "unit_var",
    "results_listbox",
    "fetch_button",
    "quit_button",
}

WIDGET_MINIMUMS = {
    "Label": 4,
    "Entry": 1,
    "Radiobutton": 2,
    "Checkbutton": 5,
    "Listbox": 1,
    "Button": 2,
}


@pytest.fixture(autouse=True)
def _no_tk_window(monkeypatch):
    """Fail if a test constructs a real Tk window."""

    def _forbid(*args, **kwargs):
        raise AssertionError(
            "Tests must not create a Tk window. "
            "Keep WeatherApp() and mainloop() inside main()."
        )

    monkeypatch.setattr(tkinter_module(), "Tk", _forbid)


def tkinter_module():
    import tkinter

    return tkinter


def source_text():
    return Path(weather_app.__file__).read_text(encoding="utf-8")


def module_tree():
    return ast.parse(source_text())


def call_name(node):
    func = node.func
    if isinstance(func, ast.Attribute):
        return func.attr
    if isinstance(func, ast.Name):
        return func.id
    return None


def class_def(tree, name):
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == name:
            return node
    return None


def function_def(tree, name):
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None


def method_def(class_node, name):
    for node in class_node.body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None


def calls_named(fn, name):
    for node in ast.walk(fn):
        if isinstance(node, ast.Call) and call_name(node) == name:
            return True
    return False


def assigned_self_attributes(class_node):
    names = set()
    for node in ast.walk(class_node):
        targets = []
        if isinstance(node, ast.Assign):
            targets = node.targets
        elif isinstance(node, ast.AnnAssign):
            targets = [node.target]
        for target in targets:
            if (
                isinstance(target, ast.Attribute)
                and isinstance(target.value, ast.Name)
                and target.value.id == "self"
            ):
                names.add(target.attr)
    return names


def _anchor_is_west(node):
    if isinstance(node, ast.Constant) and node.value == "w":
        return True
    if isinstance(node, ast.Attribute) and node.attr == "W":
        return True
    return isinstance(node, ast.Name) and node.id == "W"


def _defaults_to_imperial(init):
    """True when the unit StringVar starts as Fahrenheit.

    Both of these are accepted:
        self.unit_var = tkinter.StringVar(value="imperial")
        self.unit_var = tkinter.StringVar()
        self.unit_var.set("imperial")
    """
    for node in ast.walk(init):
        if not isinstance(node, ast.Call):
            continue
        if call_name(node) == "StringVar":
            for keyword in node.keywords:
                if (
                    keyword.arg == "value"
                    and isinstance(keyword.value, ast.Constant)
                    and keyword.value.value == "imperial"
                ):
                    return True
        if call_name(node) != "set" or not node.args:
            continue
        owner = node.func.value if isinstance(node.func, ast.Attribute) else None
        if (
            isinstance(owner, ast.Attribute)
            and isinstance(owner.value, ast.Name)
            and owner.value.id == "self"
            and owner.attr == "unit_var"
            and isinstance(node.args[0], ast.Constant)
            and node.args[0].value == "imperial"
        ):
            return True
    return False


def _left_pack_count(tree):
    count = 0
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or call_name(node) != "pack":
            continue
        for keyword in node.keywords:
            if keyword.arg == "anchor" and _anchor_is_west(keyword.value):
                count += 1
    return count


def is_main_guard(node):
    test = node.test
    if not isinstance(test, ast.Compare) or len(test.ops) != 1:
        return False
    if not isinstance(test.ops[0], ast.Eq) or len(test.comparators) != 1:
        return False
    sides = (test.left, test.comparators[0])
    has_name = any(isinstance(side, ast.Name) and side.id == "__name__" for side in sides)
    has_main = any(
        isinstance(side, ast.Constant) and side.value == "__main__" for side in sides
    )
    return has_name and has_main


@pytest.mark.parametrize(
    "text",
    ["68102", "12345", "00000", "68102-1234", "12345-6789"],
)
def test_valid_zips(text):
    assert weather_app.is_valid_zip(text) is True


@pytest.mark.parametrize(
    "text",
    [
        "",
        "6810",
        "681021",
        "68102-123",
        "68102-12345",
        "68102-123A",
        "abcde",
        " 68102",
        "68102 ",
        "68102-1234 ",
        "6810-1234",
    ],
)
def test_invalid_zips(text):
    assert weather_app.is_valid_zip(text) is False


def test_is_valid_zip_rejects_non_strings():
    assert weather_app.is_valid_zip(None) is False
    assert weather_app.is_valid_zip(68102) is False


def test_is_valid_zip_uses_fullmatch():
    tree = module_tree()
    fn = function_def(tree, "is_valid_zip")
    assert fn is not None, "Define is_valid_zip(text)."
    assert calls_named(fn, "fullmatch"), "is_valid_zip must call re.fullmatch."


@pytest.mark.parametrize(
    ("text", "state"),
    [
        ("68102", "normal"),
        ("68102-1234", "normal"),
        ("", "disabled"),
        ("6810", "disabled"),
        ("abcde", "disabled"),
        ("68102 ", "disabled"),
    ],
)
def test_fetch_button_state(text, state):
    assert weather_app.fetch_button_state(text) == state


def test_sample_weather_imperial():
    assert weather_app.sample_weather("imperial") == {
        "city": "Bellevue",
        "description": "clear sky",
        "temp": 72.0,
        "feels_like": 70.0,
        "humidity": 40,
        "wind_speed": 8.0,
    }


def test_sample_weather_metric():
    assert weather_app.sample_weather("metric") == {
        "city": "Bellevue",
        "description": "clear sky",
        "temp": 22.0,
        "feels_like": 21.0,
        "humidity": 40,
        "wind_speed": 3.6,
    }


def test_sample_weather_returns_a_new_dict():
    first = weather_app.sample_weather("imperial")
    first["city"] = "changed"
    assert weather_app.sample_weather("imperial")["city"] == "Bellevue"


def test_format_all_imperial_fields():
    weather = weather_app.sample_weather("imperial")
    assert weather_app.format_weather_lines(weather, "imperial", ALL_FIELDS) == IMPERIAL_ALL


def test_format_all_metric_fields():
    weather = weather_app.sample_weather("metric")
    assert weather_app.format_weather_lines(weather, "metric", ALL_FIELDS) == METRIC_ALL


def test_format_subset_keeps_order():
    weather = weather_app.sample_weather("imperial")
    lines = weather_app.format_weather_lines(
        weather, "imperial", {"wind", "temperature"}
    )
    assert lines == [
        "City: Bellevue",
        "Temperature: 72.0 F",
        "Wind: 8.0 mph",
    ]


def test_format_city_only_when_nothing_selected():
    weather = weather_app.sample_weather("imperial")
    assert weather_app.format_weather_lines(weather, "imperial", set()) == ["City: Bellevue"]


def test_weather_result_lines_uses_sample_for_any_zip(monkeypatch):
    def fail_urlopen(*args, **kwargs):
        raise AssertionError("Module 10 must not call the weather service")

    monkeypatch.setattr(urllib.request, "urlopen", fail_urlopen)
    imperial = weather_app.weather_result_lines("00000", "imperial", ALL_FIELDS)
    metric = weather_app.weather_result_lines("02139-1234", "metric", {"humidity"})
    assert imperial == IMPERIAL_ALL
    assert metric == ["City: Bellevue", "Humidity: 40%"]


def test_source_imports_tkinter_and_not_urllib_or_ttk():
    tree = module_tree()
    imported_tkinter = False
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "tkinter":
                    imported_tkinter = True
                if alias.name == "ttk" or alias.name.startswith("tkinter.ttk"):
                    pytest.fail("Use tkinter widgets, not ttk.")
                if alias.name == "urllib" or alias.name.startswith("urllib."):
                    pytest.fail("Module 10 uses fake data and must not import urllib.")
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            names = {alias.name for alias in node.names}
            if "ttk" in module or "ttk" in names:
                pytest.fail("Use tkinter widgets, not ttk.")
            if "urllib" in module or "urlopen" in names:
                pytest.fail("Module 10 uses fake data and must not import urllib.")
    assert imported_tkinter, "Start the file with import tkinter."
    assert "urlopen" not in source_text()


def test_weatherapp_composition_and_widgets():
    tree = module_tree()
    cls = class_def(tree, "WeatherApp")
    assert cls is not None, "Define class WeatherApp."
    assert cls.bases == [], (
        "Do not inherit from tkinter.Tk. "
        "Create the window with tkinter.Tk() inside __init__."
    )
    missing = REQUIRED_ATTRIBUTES - assigned_self_attributes(cls)
    assert not missing, f"WeatherApp must assign these attributes: {sorted(missing)}"

    counts = {name: 0 for name in WIDGET_MINIMUMS}
    disabled_button = False
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = call_name(node)
        if name in counts:
            counts[name] += 1
        if name == "Button":
            for keyword in node.keywords:
                if keyword.arg != "state":
                    continue
                value = keyword.value
                if isinstance(value, ast.Constant) and value.value == "disabled":
                    disabled_button = True
                if isinstance(value, ast.Attribute) and value.attr == "DISABLED":
                    disabled_button = True

    for name, minimum in WIDGET_MINIMUMS.items():
        assert counts[name] >= minimum, f"Create at least {minimum} {name} widget(s)."
    assert disabled_button, 'Create Get Weather with state="disabled".'
    assert _left_pack_count(tree) >= 7, (
        'Pack each Radiobutton and each Checkbutton with anchor="w" '
        "so they are left justified."
    )

    source = source_text()
    for label in (
        "ZIP code",
        "Temperature unit",
        "Weather details",
        "Results",
        "Fahrenheit",
        "Celsius",
        "Conditions",
        "Temperature",
        "Feels Like",
        "Humidity",
        "Wind",
        "Get Weather",
        "Quit",
        "<KeyRelease>",
    ):
        assert label in source, f"The GUI source must include {label!r}."

    init = method_def(cls, "__init__")
    assert init is not None
    assert _defaults_to_imperial(init), (
        "Start the unit StringVar at imperial so Fahrenheit is selected. "
        'Use value="imperial" or call self.unit_var.set("imperial").'
    )


def test_required_methods_and_main_guard():
    tree = module_tree()
    cls = class_def(tree, "WeatherApp")
    assert cls is not None

    update = method_def(cls, "update_fetch_button")
    fetch = method_def(cls, "fetch")
    quit_app = method_def(cls, "quit_app")
    assert update is not None, "Define WeatherApp.update_fetch_button."
    assert fetch is not None, "Define WeatherApp.fetch."
    assert quit_app is not None, "Define WeatherApp.quit_app."
    assert calls_named(update, "fetch_button_state")
    assert calls_named(fetch, "weather_result_lines")
    assert calls_named(fetch, "delete")
    assert calls_named(fetch, "insert")
    assert calls_named(quit_app, "destroy")

    main_fn = function_def(tree, "main")
    assert main_fn is not None, "Define main()."
    assert calls_named(main_fn, "WeatherApp")
    assert calls_named(main_fn, "mainloop")

    saw_guard = False
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        if isinstance(node, ast.If) and is_main_guard(node):
            saw_guard = True
            assert calls_named(node, "main"), (
                'if __name__ == "__main__" must call main().'
            )
            continue
        for sub in ast.walk(node):
            if not isinstance(sub, ast.Call):
                continue
            name = call_name(sub)
            assert name not in {"WeatherApp", "main", "mainloop"}, (
                "Do not create the window or call mainloop at import time. "
                "Call main() only from the __name__ guard."
            )
    assert saw_guard, 'End the file with if __name__ == "__main__": main().'
