# File: weather_app.py
# Module: Module 10 - tkinter GUI
# Name/Author:
# Date:
#
# Rename this file to weather_app.py before you start editing.
# Complete every # TODO comment. The docstrings tell you what each
# function is for. You will need to remove the pass statements and 
# replace them with your own code.
# Do not create a WeatherApp at the top of this file.
# Importing the file must not open a window.
#
# Run these commands from the repository root when you are ready to try it:
#   python weather_app.py
#   python -m pytest
# Pytest reads your functions and your source. It does not open a window.
# A test fails if this file constructs tkinter.Tk while the tests run, and
# tests/conftest.py stops a test that runs longer than a few seconds.
# Keep mainloop() inside main().

import tkinter

# TODO 1: Import the re module. You need it to check the ZIP code.
# Do not import urllib. This week uses fake weather, not the internet.
# Do not use ttk.


def is_valid_zip(text):
    """Decide whether text is a ZIP code the weather window can accept.

    Purpose:
        Accept a 5-digit ZIP code, such as 68102, or a ZIP+4 code,
        such as 68102-1234. Reject everything else.

    Parameters:
        text: The characters typed in the ZIP code entry.

    Returns:
        True when text is an accepted ZIP code, otherwise False.
    """
    # TODO 2: Return False when text is not a string.
    # TODO 3: Use re.fullmatch and a regular expression you write.
    #       Accept only five digits, or five digits, a hyphen, and four
    #       more digits. Reject spaces, letters, four digits, six digits,
    #       and a ZIP+4 code with the wrong number of digits.

    pass


def fetch_button_state(text):
    """Choose whether Get Weather is clickable.

    Purpose:
        Turn the button on only while the ZIP code is valid.

    Parameters:
        text: The characters currently in the ZIP code entry.

    Returns:
        "normal" when the ZIP code is valid, otherwise "disabled".
    """
    if is_valid_zip(text):
        return "normal"
    return "disabled"


def sample_weather(unit):
    """Return fake weather for Bellevue, NE so the window can be tested.

    Purpose:
        Provide one dictionary for Fahrenheit and one for Celsius.
        The ZIP code is not used. 68102 and 02139-1234 both show Bellevue, NE.
        That is only for this week.

    Parameters:
        unit: "imperial" for Fahrenheit, or "metric" for Celsius.

    Returns:
        A new weather dictionary on every call.
    """
    # Imperial is labeled F in the listbox. Metric is labeled C.
    # Each call returns a new dictionary.
    if unit == "imperial":
        return {
            "city": "Bellevue",
            "description": "clear sky",
            "temp": 72.0,
            "feels_like": 70.0,
            "humidity": 40,
            "wind_speed": 8.0,
        }
    if unit == "metric":
        return {
            "city": "Bellevue",
            "description": "clear sky",
            "temp": 22.0,
            "feels_like": 21.0,
            "humidity": 40,
            "wind_speed": 3.6,
        }
    # TODO 4: Raise ValueError when unit is neither "imperial" nor "metric".


def format_weather_lines(weather, unit, selected):
    """Turn one weather dictionary into the lines for the listbox.

    Purpose:
        Always start with the city. Then add one line for each selected
        detail, in this order: conditions, temperature, feels like,
        humidity, wind. Skip any detail that is not in selected.

    Parameters:
        weather: A dictionary with keys city, description, temp,
            feels_like, humidity, and wind_speed.
        unit: "imperial" or "metric".
        selected: A set of zero or more of "conditions", "temperature",
            "feels_like", "humidity", and "wind".

    Returns:
        A list of strings, one string per listbox row.

    Imperial, with every option selected, looks like this:

        City: Bellevue
        Conditions: clear sky
        Temperature: 72.0 F
        Feels like: 70.0 F
        Humidity: 40%
        Wind: 8.0 mph

    Metric, with every option selected, looks like this:

        City: Bellevue
        Conditions: clear sky
        Temperature: 22.0 C
        Feels like: 21.0 C
        Humidity: 40%
        Wind: 3.6 m/s

    If nothing is selected, the only line is City: Bellevue.
    """
    # TODO 5: Write the code to format the weather lines.
    # Use C and m/s when unit is "metric". Otherwise use F and mph.
    # Print temperature, feels like, and wind with one decimal place.
    # Print humidity as an integer followed by %.
    # Build the list in the order described above and return it.
    pass


def weather_result_lines(zip_code, unit, selected):
    """Return the listbox lines for one click of Get Weather.

    Purpose:
        This week, ignore the ZIP code and use the fake Bellevue weather.

    Parameters:
        zip_code: The text from the ZIP code entry. Not used this week.
        unit: "imperial" or "metric".
        selected: The set of detail names the user checked.

    Returns:
        The list of strings from format_weather_lines.
    """
    # TODO 6: Return the listbox lines for this click.
    # Call sample_weather(unit).
    # Return format_weather_lines for that dictionary, this unit, and selected.
    # Do not call urllib from this function.
    pass


class WeatherApp:
    """The weather window.

    Purpose:
        Create the widgets and respond to Get Weather and Quit.
        Do not inherit from tkinter.Tk. Create a tkinter.Tk window
        inside __init__ and store it on self.

    The window uses these labels, exactly:
        ZIP code
        Temperature unit
        Weather details
        Results
    """

    def __init__(self):
        """Build the window and its widgets.

        Parameters:
            self: The WeatherApp being created.

        Returns:
            None
        """
        self.main_window = tkinter.Tk()
        self.main_window.title("Weather")

        # TODO 7: Create the rest of the widgets on self.main_window.
        # Create self.zip_label, a Label with the text "ZIP code", and pack it.
        # 
        # Create self.zip_entry, an Entry.
        # Bind self.zipp_entry "<KeyRelease>" to self.update_fetch_button.
        # 
        # Create a Label with the text "Temperature unit" and pack it.
        # 
        # Create self.unit_var, a StringVar with value "imperial",
        # so Fahrenheit starts selected.
        # Create two Radiobutton widgets that share self.unit_var.
        # Fahrenheit uses the value "imperial". Celsius uses "metric".
        # Label the buttons "Fahrenheit" and "Celsius".
        # 
        # Create a Label with the text "Weather details" and pack it.
        # 
        # Create five IntVar objects, one per checkbox.
        # Create five Checkbutton widgets. Label them, exactly,
        # "Conditions", "Temperature", "Feels Like", "Humidity", and "Wind".
        # Give each checkbox its own IntVar.
        # 
        # Pack each Radiobutton and each Checkbutton with anchor="w"
        # so the controls line up on the left side of the window.
        # pack() without an anchor centers them in the frame.
        # 
        # Create a Label with the text "Results" and pack it.
        # 
        # Create self.results_listbox, a Listbox, and pack it.
        # 
        # Create self.fetch_button, a Button labeled "Get Weather",
        # with state="disabled" and command self.fetch. Pack it.
        # 
        # Create self.quit_button, a Button labeled "Quit",
        # with command self.quit_app. Pack it.

    def update_fetch_button(self, event=None):
        """Enable or disable Get Weather after the ZIP code changes.

        Purpose:
            The entry calls this on every KeyRelease.

        Parameters:
            self: The WeatherApp.
            event: The KeyRelease event from tkinter. It may be omitted.

        Returns:
            None
        """
        # TODO 8: Enable or disable Get Weather from the ZIP code entry.
        # Read the ZIP code from self.zip_entry.
        # Set self.fetch_button's state from fetch_button_state.
        # A valid ZIP code uses "normal". Anything else uses "disabled".
        pass

    def fetch(self):
        """Fill the listbox from the fake weather.

        Purpose:
            Run when the user clicks Get Weather.

        Parameters:
            self: The WeatherApp.

        Returns:
            None
        """
        # TODO 9: Fill the listbox from the choices on the window.
        # Read the ZIP code from self.zip_entry.
        # Read the unit from self.unit_var.
        # Build a set from the checkboxes that are checked.
        # Use these names: "conditions", "temperature", "feels_like",
        # "humidity", and "wind".
        # Call weather_result_lines with the ZIP code, the unit, and that set.
        # delete the current rows from self.results_listbox,
        # then insert each returned line.
        pass

    def quit_app(self):
        """Close the window.

        Purpose:
            Run when the user clicks Quit.

        Parameters:
            self: The WeatherApp.

        Returns:
            None
        """
        # TODO 10: Call destroy on self.main_window.
        pass


def main():
    """Open the weather window and wait for the user.

    Purpose:
        Start the program. Called only from the __name__ guard below.

    Parameters:
        None

    Returns:
        None

    Try the finished window:
        Get Weather stays gray until the ZIP code is five digits, or
        five digits, a hyphen, and four digits.
        Choose Fahrenheit or Celsius, check one or more boxes, and
        click Get Weather. The listbox shows the fake Bellevue, NE weather.
        The radio buttons and checkboxes sit on the left side.
        Clear the ZIP code. Get Weather turns gray again.
        Quit closes the window.
    """
    app = WeatherApp()
    app.main_window.mainloop()


if __name__ == "__main__":
    main()
